Haiku Messenger — group invite fixed files

Extract this archive at the repository root, preserving directories. It contains complete replacement files:

- apps/api/src/routes/groups.ts — invite creation/list/revocation/redemption, join approval endpoints, rate limits, block/status checks, and admin notifications.
- apps/mobile/src/screens/GroupDetailScreen.tsx — create/share/revoke UI and join-request management.
- apps/mobile/src/screens/NotificationsScreen.tsx — routes group join-request notifications to group management.
- tests/api-smoke.test.ts — anonymous access rejection coverage for invite endpoints.

Validation run in the workspace: all workspace TypeScript checks passed; API tests 11/11; mobile test 1/1; admin production build succeeded. Invite SQL/database behavior was not tested against PostgreSQL, and no migration or deployment was run.
